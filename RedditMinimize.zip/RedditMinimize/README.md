"# RedditMinimize: click on the "-" character at the top left to minimize a post. If you go to another subreddit hit the refresh button to generate the buttons" 
