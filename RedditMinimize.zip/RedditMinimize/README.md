"# RedditMinimize: click on the "-" character at the top left to minimize a post. If the buttons dont appear immediately, scroll to make them show up." 
